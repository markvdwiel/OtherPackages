`acghClustering` <-
function(data.content,data.info,
                           max.cluster.size=9,
                           distance.type="base-pair-count",
                           decay.factor=1)
{
    library("RBGL")
    library("partitions")

    conc <- function(p1, p2)
    {
        if(p1 == p2) {if(p1 == 0) return(0) else return(1)} else return(-1)
    }

    newtcrossprod <- function(v) {
        res <- c()
        vl <- length(v)
        for(i in 2:vl){
            for(j in 1:(i-1))
                res <- c(res, conc(v[i],v[j]))
        }
        return(res)
    }

    conc2 <- function(x, y) ifelse(x != y, -1, x*y)
    newtcrossprod2 <- function(v) {
        w <- outer(v, v, conc2)
        return(w[upper.tri(w)])
    }


    g.o.f <- function(regions)
    {
        regions <- sort(regions)
        size <- length(regions)
        local.distance <- distance.matrix[regions, regions]

        suff.stat <- numeric(size + 1)
        x <- rbind(data.content[regions,])
        suff.stat[1:size] <- rowSums(x)
        if(size > 1)
        {
            y <- matrix(, (size - 1)*size/2, n)
            for(i in 1:n)
            {
                y[,i] <- newtcrossprod2(x[,i])
            }
            z <- local.distance[upper.tri(local.distance)]
            suff.stat[size + 1] <- sum(colSums(y*z))

        } else {

            suff.stat[size + 1] <- 0
        }

        llik <- function(u)
        {
            s0 <- state.matrix[1:size, 1:(n.category^size)]
            tmp1 <- rbind(s0, cross.sums.list[[size]][regions[1],])

            ## "expUsum" is a vector of "3^size"
            tmp2 <- exp(t(u) %*% tmp1)
            u0 <- -log(sum(tmp2))
            loglik <- n*u0 + sum(u*suff.stat)

            return(loglik)
        }

        grad.llik <- function(u)
        {
            s0 <- state.matrix[1:size, 1:(n.category^size)]
            tmp1 <- rbind(s0, cross.sums.list[[size]][regions[1],])

            ## "expUsum" is a vector of "3^size"
            tmp2 <- exp(t(u) %*% tmp1)
            sumVec <- tmp2 %*% t(tmp1)
            sumNum <- sum(tmp2)

            loglik.grad <- rep(0, size + 1)
            loglik.grad <- suff.stat - n*sumVec/sumNum

            return(as.numeric(loglik.grad))
        }

        init.par <- rep(0, size + 1)
        max.iter <- 1e4

        result <- optim(init.par, llik, gr=grad.llik, method="L-BFGS-B",
                        control=list(fnscale=-1, maxit=max.iter),lower=c(rep(-100,size),0))

        if(result$conv == 1)
        {
            max.iter <- 1e5
            result <- optim(init.par, llik, gr=grad.llik, method="L-BFGS-B",
                            control=list(fnscale=-1, maxit=max.iter),lower=c(rep(-100,size),0))
        }

        if(result$conv == 0)
            params <- result$par
        else {
            print(result$message)
            print(regions)
            stop('parameters do not converge!')
        }

        dev <- -2*llik(params)
        g.coeff <- params[length(params)]

        list(deviance=dev, gamma.coeff=g.coeff)
        ##    param0 <- (-deviance/2 - sum(params*suff.stats))/n
    }


    search.dag <- function(gof)
    {
        deviance.weight <- gof[1:max.cluster.size,]
        node.mat <- matrix(0, max.cluster.size, p)

        ## first digit: present cluster size, last three digits: starting region number
        ## e.g. 300021 => cluster with size 3 starting with region 21
        ## in this case, separator = 100000 which separate cluster size and region number
        separator <- 10^ceiling(log10(p) + 1)
        for(i in 1:max.cluster.size)
        {
            node.mat[i, ] <- i*separator + 1:p
        }
        edge.out <- rep(node.mat, each=max.cluster.size)

        node.mat <- cbind(node.mat, matrix(1, max.cluster.size, max.cluster.size))
        edge.in <- matrix(, max.cluster.size^2, p)
        for(i in 1:p)
        {
            edge.in[, i] <- c(node.mat[, (i + 1):(i + max.cluster.size)])
        }
        edge.in <- c(edge.in)

        edge.out <- c(rep(0, max.cluster.size), edge.out)
        edge.in <- c(node.mat[, 1], edge.in)
        edge <- as.data.frame(cbind(edge.out, edge.in))

        non.terminal <- edge.in > 1
        terminal <- edge.in == 1

        edge$weight <- numeric(length(edge.in))
        edge$weight[non.terminal] <- deviance.weight[(edge.in[non.terminal] %/% separator)+
                                                     (edge.in[non.terminal] %% separator - 1)*
                                                     max.cluster.size]
        edge$weight[terminal] <- 0
        edge <- unique(edge)


        V <- unique(c(edge.out, edge.in))
        eL <- vector("list", length=length(V))
        names(eL) <- V
        for(i in 1:length(V))
        {
            ind <- (edge[,1] == V[i])
            eL[[i]] <- list(edges=as.character(edge[ind, "edge.in"]),
                            weights=edge[ind, "weight"])
        }
        DAG <- new("graphNEL", nodes=as.character(V), edgeL=eL, edgemode="directed")

        s.path <- sp.between(DAG, "0", "1")
        model <- as.numeric(as.numeric(s.path$`0:1`$path) %/% separator)[2:(length(s.path$`0:1`$path)-1)]

        dev <- s.path$`0:1`$length_detail[[1]]

        names(dev) <- NULL
        dev <- dev[1:length(model)]

        list(model=model, deviance=dev)
    }


    #data.table <- read.table(file=data.file.name, header=TRUE, na.strings=c("NA","#N/A"))
    colnames(data.content) <- as.character(1:ncol(data.content))

    data.content[data.content <= -1] <- -1
    data.content[data.content >= 1] <- 1
    data.category <- c(0, -1, 1)
    n.category <- length(data.category)

    p <- nrow(data.content)
    n <- ncol(data.content)

    cont.table <- array(, dim=c(p, n, n.category))
    dimnames(cont.table) <- list(NULL, NULL, c("normal", "loss", "gain"))
    cont.table[,,"normal"] <- as.numeric(data.content == 0)
    cont.table[,,"loss"] <- as.numeric(data.content == -1)
    cont.table[,,"gain"] <- as.numeric(data.content == 1)

    summ.table <- apply(cont.table, c(1,3), sum)
    dimnames(summ.table) <- list(NULL, c("normal", "loss", "gain"))

    chromosome.index <- unique(data.info$chromosome)
    distance.matrix <- matrix(, p, p)
    for(i in chromosome.index)
    {
        index <- which(data.info$chromosome == i)
        n.index <- length(index)
        if(distance.type == "base-pair-count")
        {
            x <- data.info$bpstart[index]

        } else if(distance.type == "clone-count") {

            x <- cumsum(c(0, data.info$nclone[index]))
        }
        y <- outer(1:n.index, 1:n.index, function(i, j) abs(x[i] - x[j]))

        ## first take reciprocal of distance
        y <- ifelse(y > 0, y^(-decay.factor), 0)

        ## normalize pairwise distance
        y <- y/max(y)

        distance.matrix[index, index] <- y
    }
    ## diagonal of distance.matrix should be Inf but we let zero.
    diag(distance.matrix) <- 0
    distance.matrix[is.na(distance.matrix)] <- 0

    state.matrix <- matrix(, max.cluster.size, n.category^max.cluster.size)
    for(i in 1:max.cluster.size)
        state.matrix[i,] <- rep(rep(data.category, each=n.category^(i - 1)),
                                n.category^(max.cluster.size - i))

    cross.sums.list <- vector("list", max.cluster.size)
    cross.sums.list[[1]] <- matrix(0, p, n.category)
    for(i in 2:max.cluster.size)
    {
        cross.sums.list[[i]] <- matrix(, p - i + 1, n.category^i)
        i.state <- state.matrix[1:i, 1:(n.category^i)]

        x <- matrix(, (i - 1)*i/2, n.category^i)
        for(j in 1:n.category^i)
        {
            x[,j] <- newtcrossprod2(i.state[,j])
        }

        for(j in 1:(p - i + 1))
        {
            tmp <- distance.matrix[j:(j + i - 1), j:(j + i - 1)]
            y <- tmp[upper.tri(tmp)]
            cross.sums.list[[i]][j,] <- colSums(x*y)
        }
    }


    gof.matrix <- matrix(, max.cluster.size*2, p)
    normal.region <- which(summ.table[,"normal"] == n)
    normal.cluster <- matrix(FALSE, max.cluster.size*2, p)
    for(i in 1:max.cluster.size)
    {
        for(j in 1:(p - i + 1))
        {
            regions <- j:(j + i - 1)
            if(length(unique(data.info$chromosome[regions])) > 1)
                gof.matrix[i, j] <- Inf
            else
                gof.matrix[i, j] <- g.o.f(regions)$deviance
            if(all(regions %in% normal.region)) normal.cluster[i, j] <- TRUE
        }
    }
    gof.matrix[is.na(gof.matrix)] <- Inf
    epsilon <- 1e-5
    gof.matrix[normal.cluster] <- gof.matrix[normal.cluster] + epsilon

    clusters <- search.dag(gof.matrix)
    segments <- cumsum(clusters$model)
    gamma.coeff <- numeric(length(segments))
    for(i in 1:length(segments))
    {
        if(i == 1) regions <- 1:segments[1]
        else regions <- (segments[i - 1] + 1):segments[i]
        gamma.coeff[i] <- g.o.f(regions)$gamma.coeff
    }
    clusters$coefficients <- (exp(gamma.coeff) - 1)/(exp(gamma.coeff) + 1)

    clusterresmat <- c();
    for(j in 1:length(clusters[[1]])) {
        for(k in 1:clusters[[1]][j]) {
            clusterresmat <- rbind(clusterresmat,c(j,clusters[[2]][j],clusters[[3]][j]))}
    }
    clusterresmat <- data.frame(clusterindex=clusterresmat[,1],deviance=clusterresmat[,2],strengthgamma = clusterresmat[,3])
    return(clusterresmat)
}
