acghHierarchTest <-
function (clust, pvalsreg, pvalsclust, alpha = 0.1,data.info) 
{   
     library(multtest)
    holmpvalsreg <- function(scc, cl, weightcl) {
        cli <- which(scc == cl)
        pvo <- pvobs_sel[[cli]]
        if (length(pvo) == 1) {
            return(matrix(c(pvo, pvo * weightcl[cl]), nrow = 1))
        }
        else {
            mtsimple <- mt.rawp2adjp(pvo, proc = "Holm")
            mtsimple$adjp[1, 2] <- mtsimple$adjp[1, 1] * (length(pvo) - 
                1)
            mtsimpleord <- sapply(mtsimple$adjp[order(mtsimple$index), 
                2] * weightcl[cl], function(x) {
                min(x, 1)
            })
            return(data.frame(t(pvo), mtsimpleord))
        }
    }
    mtsimple_reg <- mt.rawp2adjp(pvalsreg, proc = c("BY", "Holm", 
        "Bonferroni"))
    mtsimpleord_reg <- data.frame(clust, mtsimple_reg$adjp[order(mtsimple_reg$index), 
        3])
    mtsimple_cl <- mt.rawp2adjp(pvalsclust, proc = c("BY", "Holm", 
        "Bonferroni"))
    mtsimpleord_cl <- mtsimple_cl$adjp[order(mtsimple_cl$index), 
        3]
    nreg <- length(clust)
    ncmax <- max(clust)
    nregcl <- sapply(1:ncmax, function(cl) {
        return(length(clust[clust == cl]))
    })
    weightmeth <- "unif"
    if (weightmeth == "unif") {
        weightnorm <- rep(ncmax, ncmax)
    } else {
        weight <- nregcl/nreg
        weightnorm <- sum(weight)/weight
    }
    sigreg <- list()
    nclust <- max(clust)
    stop <- 0
    selectsigcl <- which(pvalsclust <= alpha/nclust)
    if(length(selectsigcl)>0){
        sigcl <- selectsigcl
        pvadj <- (pvalsclust * nclust)[selectsigcl]
        pvobs_clust <- data.frame(clust, pvalsreg)
        while (stop == 0) {
            pvobs_sel <- lapply(as.list(selectsigcl), function(cl) {
                return(t(as.matrix(pvobs_clust[pvobs_clust[, 1] == 
                    cl, -1])))
            })
            allpvalreg <- lapply(as.list(selectsigcl), holmpvalsreg, 
                weightcl = weightnorm, scc = selectsigcl)
            sigreg0 <- lapply(as.list(selectsigcl), function(cl, 
                scc) {
                scc <- selectsigcl
                cli <- which(scc == cl)
                punadj <- allpvalreg[[cli]][, 1]
                padj <- allpvalreg[[cli]][, 2]
                return(list(cl, punadj, padj))
            }, scc = selectsigcl)
            sigreg <- c(sigreg, sigreg0)
            whichall <- sapply(selectsigcl, function(cl, scc) {
                cli <- which(scc == cl)
                padj <- allpvalreg[[cli]][, 2]
                return(max(padj))
            }, scc = selectsigcl)
            el <- length(whichall[whichall <= alpha])
            whichclrm <- selectsigcl[whichall]
            if (el == 0) 
                stop <- 1
            else {
                nclust <- nclust - el
                if (weightmeth == "unif") {
                    weightnorm <- rep(nclust, nclust)
                } else {
                    weight <- weight[-whichall]
                    weigthnorm <- sum(weight)/weight
                }
                selectsigcl <- setdiff(which(pvalsclust <= alpha/nclust), 
                    sigcl)
                pvadj <- c(pvadj, (pvalsclust * nclust)[selectsigcl])
                sigcl <- c(sigcl, selectsigcl)
                if (length(selectsigcl) == 0) {
                    stop <- 1
                }
            }
        }
        pvclboth <- cbind(pvalsclust[sigcl], pvadj)
        pvord <- sort(pvclboth[, 1], index = TRUE)
        pvadjnew <- c(pvadj[pvord$ix[1]])
        if (length(pvadj) > 1) {
            for (i in 2:length(pvadj)) {
                if (pvadj[pvord$ix[i]] <= pvadjnew[i - 1]) 
                    pvadjnew <- c(pvadjnew, pvadjnew[i - 1])
                else pvadjnew <- c(pvadjnew, pvadj[pvord$ix[i]])
            }
        }
        pvadjnew <- pvadjnew[order(pvord$ix)]
        overview <- function(cl) {
            nr <- nregcl[cl]
            pvalcl <- rep(pvalsclust[cl], nr)
            pvsimplecl <- rep(mtsimpleord_cl[cl], nr)
            cli <- which(sigcl == cl)
            pvsimplereg <- mtsimpleord_reg[mtsimpleord_reg[, 1] == 
                cl, 2]
            pvaladjcl <- rep(pvadjnew[cli], nr)
            clusr <- rep(cl, nr)
            pvsreg <- sigreg[[cli]][[2]]
            pvsadjreg <- sigreg[[cli]][[3]]
            regions <- which(clust == cl)
            dfregsel <- data.info[regions,]
            ds <- data.frame(regions,dfregsel,clusr, pvsimplecl, pvalcl, 
                pvaladjcl, pvsimplereg, pvsreg, pvsadjreg)
            return(ds)
        }
        overviewcomp <- lapply(sigcl, overview)
        return(overviewcomp)
        } else { #no significant clusters found
        print("No significant results found")
        overviewcomp <- list()
        return(overviewcomp)
        }
}
