`pvalschisq` <-
function(datacgh,sepfile="no", group,groupnames,clinvar,whclinvar,niter=10000,af=0){
    #sepfile="no"; group<-c(7,30);groupnames<-c("MSI+", "CIN+");niter=1000;af=0;
    levels<-sort(unique(unlist(as.list(datacgh))))
    #datacgh:  input object; data.frame
    
    

    
    ########FUNCTIONS #################
    countlev2 <- function(row,level)
    {
    length(row[row==level])
    }
        
    countall2 <- function(row,levels)
    {
    sapply(levels,countlev2,row=row)
    }
        
    countallrow <- function(mat,levels)
    {
        cmat <- c()
        for (i in 1:nrow(mat))
        {
        cmat <- rbind(cmat,countall2(mat[i,],levels))
        }
        return(cmat)
    }
    
    pvalpermtwono <- function(pl,nit)
    {
        pv <- c(1)
        for (i in 2:nit)
        {
        if(pl[i]==pl[i-1]) pv <- c(pv,pv[i-1]) else pv <- c(pv,(nit-i+1)/nit)
        }
        return(pv)
    }
    
    
    pvalfuntwono <- function(lijst,nit)
    {
        obs <- lijst[1]
        lijstperm <- lijst[2:(nit+1)] #changed 23/7/09
        tlarg <- length(lijstperm[lijstperm >= obs])/nit
        return(tlarg)
    }
    
    includewh <- function(exprow, cutp)
    {
        exprow2 <- matrix(exprow,nrow=2)
        exprow3 <- exprow2[1,]+exprow2[2,]
        sapply(exprow3,function(x)ifelse(x>cutp,1,0))
    }
    
    #### START READING THE DATA
    
    
    mcgroups <- matrix(c(1,2),ncol=2,byrow=TRUE)
    #} else #{mcgroups <- matrix(comparison,ncol=2,byrow=TRUE)}
    
    if(sepfile=="yes"){orderclvar<-"no"} else {orderclvar <- "yes"}
    
    twosided <- "no"
    
    if (orderclvar == "yes"){groupcum <- c(0,cumsum(group))}
    
    lossonly <- function(x){min(x,0)}
    gainonly <- function(x){if(x>=1){return(1)} else {return(0)}}
    gainandamplification <- function(x){if(x<1){return(0)} else {return(x)}}
    countnonnull <- function(row){return(length(row[row!=0]))}
    
    Xmat <- as.matrix(datacgh)
    
    wr <- apply(Xmat,1,countnonnull)
    nc <-ncol(Xmat)
    whichrows <- which(wr>=nc*af)
    Xmat <- Xmat[whichrows,]
    
    
    if (orderclvar=="no")
    {
    dataclinvar <- read.delim(clinvarfile,header=TRUE, sep="\t", na.strings = c("NA","#N/A"),comment.char="%")
    clinvarname <- colnames(dataclinvar)[whclinvar]
    dcv <- dataclinvar[,whclinvar]
    sortdcv <- order(dcv)
    dcvsort <- dcv[sortdcv]
    whlev <- levels(dcvsort)
    groupnames <- sapply(whlev,function(x)paste(clinvarname,"_",x,sep=""))
    Xmat <- Xmat[,sortdcv] #columns of data matrix are ordered according to the groups. Columns should be ordered #according to rows in clinical var data set!
    group <- sapply(whlev,function(x)length(dcvsort[dcvsort==x]))
    groupcum <- c(0,cumsum(group))
    }
    #groupnames
    
    
    
    
    groupcumpl1 <- groupcum+1
    allreg <- c()
    for (j in 1:length(group)) allreg <- rbind(allreg,c(groupcumpl1[j],groupcum[j+1]))
    nclass <- length(levels)
    ngroup <- length(group)
    nr <- nrow(Xmat)
    ncomp <- nrow(mcgroups)
    
    createcount <- function(X,groupcum,levels,groupnames,nclass)
    {   
        countallgr <- c()
        for (i in 2:length(groupcum))
        {
        Xmat <- X[,((groupcum[i-1]+1):groupcum[i])]
        countgroup <- countallrow(Xmat,levels)
        countallgr <- cbind(countallgr,countgroup)
        }
        
        
        ccgall <- c()
        if (nclass==3)
        {
        for (i in 1:length(groupnames))
        {
        ccg <- c(paste("nloss_",groupnames[i],sep=""), paste("nnorm_",groupnames[i],sep=""),paste("ngain_",groupnames[i],sep=""))
        ccgall <- c(ccgall,ccg)
        }
        }
        if (nclass==4)
        {
        for (i in 1:length(groupnames))
        {
        ccg <- c(paste("nloss_",groupnames[i],sep=""), paste("nnorm_",groupnames[i],sep=""),paste("ngain_",groupnames[i],sep=""),paste("namp_",groupnames[i],sep=""))
        ccgall <- c(ccgall,ccg)
        }
        }
        colnames(countallgr) <- ccgall
        return(countallgr)
    }
    
    
    
    ########MAKE SUMMARY WITH FREQUENCIES  ########
    groupfreq <- createcount(Xmat,groupcum,levels,groupnames,nclass)
    
    ########Test + permutations   ########
    expectfun <- function(compgr, lijst, all)
    {
        mj <- matrix(c(group[compgr[1]],group[compgr[2]]),nrow=2)
        M <- sum(mj)
        sam1 <- lijst[all[compgr[1],1]:all[compgr[1],2]]
        sam2 <- lijst[all[compgr[2],1]:all[compgr[2],2]]
        count1 <- countall2(sam1,levels)
        count2 <- countall2(sam2,levels)
        counttot <- count1 + count2
        expect <- mj%*%counttot/M
        #obsminexpsq <- sum((rbind(count1,count2)-expect)^2/expect)
        return(expect)
    }
    
    
    TESTchisq <- function(lijstX,compgr,ncX,nctot1,nctot2) #lijst is data, all is sample subsets per group 
    {
        lijst <- lijstX[1:ncX]
        expect0 <- matrix(lijstX[(ncX+1):nctot1],nrow=2)
        include0 <- lijstX[(nctot1+1):nctot2]
        if (length(include0[include0==1]) <=1) return(0)
        else
        {
        expect0inc <- rbind(include0,expect0)[,include0==1]
        expect0 <- expect0inc[-1,]
        sam1 <- lijst[1:group[compgr[1]]]
        sam2 <- lijst[(group[compgr[1]]+1):ncX]
        count1 <- countall2(sam1,levels)
        count2 <- countall2(sam2,levels)
        count12inc <-(rbind(include0,count1,count2))[,include0==1]
        count12 <- count12inc[-1,]
        obsminexpsq <- sum((count12-expect0)^2/expect0)
        #return(list(sam2,count12,expect0,obsminexpsq))
        return(obsminexpsq)
        }
    }
    
    ####observed values  #########  AND  ####Permutation algorithm   #####
    
    TESTobs <- c() 
    expectall <- c()
    includeall <- c()
    for (j in 1:ncomp) 
    {
        gr <- mcgroups[j,]
        expect0 <- t(apply(Xmat,1,expectfun,compgr=gr,all=allreg))
        includecol <- t(apply(expect0,1,includewh,cutp=0))
        Xmatgr <- cbind(Xmat[,allreg[gr[1],1]:allreg[gr[1],2]],Xmat[,allreg[gr[2],1]:allreg[gr[2],2]])
        XE <-cbind(Xmatgr,expect0,includecol)
        ncX <- ncol(Xmatgr)
        nctot1 <- ncol(Xmatgr) + ncol(expect0)
        nctot2 <- ncol(Xmatgr) + ncol(expect0) + ncol(includecol)
        TESTobs0 <- apply(XE,1,TESTchisq,compgr=gr,ncX=ncX,nctot1=nctot1,nctot2=nctot2)
        expectall <- rbind(expectall,expect0)
        includeall <- rbind(includeall,includecol)
        TESTobs <- c(TESTobs,TESTobs0)
    }
    
    pmt <- proc.time()
    TESTpermall <- c()
    #niter <- 500
    for (j in (1:ncomp))
    {
        gr <- mcgroups[j,]
        Xmatgr <- cbind(Xmat[,allreg[gr[1],1]:allreg[gr[1],2]],Xmat[,allreg[gr[2],1]:allreg[gr[2],2]])
        expect0 <- expectall[((j-1)*nr+1):(j*nr),]
        include0 <- includeall[((j-1)*nr+1):(j*nr),]
        ncX <- ncol(Xmatgr)
        nctot1 <- ncol(Xmatgr) + ncol(expect0)
        nctot2 <- ncol(Xmatgr) + ncol(expect0) + ncol(includecol)
        TESTperm <- c()
        for (i in (1:niter))
            {
            print(i)
            #set.seed(seeds[i])
            ranseq <- sample(1:ncX)
            permmat <- cbind(Xmatgr[,ranseq],expect0,include0)
            TESTperm0 <- apply(permmat,1,TESTchisq, compgr=gr, ncX=ncX,nctot1=nctot1,nctot2=nctot2)
            TESTperm <- cbind(TESTperm,TESTperm0) 
            }
        TESTpermall <- rbind(TESTpermall,TESTperm)
    }
    proc.time() - pmt
    
    
    #####p-val computation  ####
    TESTpermsort <- matrix(apply(TESTpermall,1,sort),byrow=TRUE,nrow=nrow(TESTpermall))
    TESTpermind <- matrix(apply(TESTpermall,1,order),byrow=TRUE,nrow=nrow(TESTpermall))
    TESTpermobs <- cbind(TESTobs,TESTpermsort)
    
    
    pvalue <- apply(TESTpermobs,1,pvalfuntwono, nit=niter)
    pvpa <- apply(TESTpermsort,1,pvalpermtwono, nit=niter)
    pvpa <- apply(cbind(t(pvpa),TESTpermind),1,function(x){el <- length(x);
    x1 <- x[1:(el/2)];x2 <- x[(el/2+1):el]; f1 <- array(dim=c(el/2));f1[x2]<-x1;return(f1)})
    pvpa <- t(pvpa)
    allres <- list(pvalue,pvpa,groupfreq)
    return(allres)
}
