`pvclust` <-
function(clust,pvregperm,sumstat="min"){ #pvregperm should be a list object of which the first repr. pvobs and the 2nd pvperm
    nclust <- max(clust)
    pvreg <- list(pvregperm[[1]],pvregperm[[2]])
    pvperm_clust <- data.frame(clust,pvreg[[2]])
    pvobs_clust <- data.frame(clust,pvreg[[1]])
    
    sumpobs <- sapply(1:max(clust),function(cl){pvs <- pvobs_clust[pvobs_clust[,1]==cl,-1];
    if(sumstat=="min") return(min(pvs)) else return(median(pvs))})
    sumpperm <- apply(matrix(1:max(clust),nrow=1),2,
    function(cl){
        pvs <- pvperm_clust[pvperm_clust[,1]==cl,-1,drop=FALSE]
        if(sumstat=="min") mins <- as.vector(apply(pvs,2,min)) else mins <- as.vector(apply(pvs,2,median))
        return(mins)
        })
    sump <- rbind(sumpobs,sumpperm)
    
    pvalone <- function(lijst){
        nit<- length(lijst)-1
        obs <- lijst[1]
        lijstperm <- lijst[2:(nit+1)] 
        tsmall <- length(lijstperm[lijstperm <= obs])/nit
        return(tsmall)
    }
    
    pvalsclust <- apply(sump,2,pvalone)
    return(pvalsclust)
}
