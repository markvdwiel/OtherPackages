plot_dnaCplusT <- function(clust,testresults,datacgh,datainfo,sepfile="no", group, groupnames, clinvar, whclinvar, alpha=0.1){
    #clust<-clust;testresults <- testresults;datacgh<-datacgh;datainfo<-datainfo;group<- c(7,30);alpha<-0.2
    
    ## make axes
    clusters<-clust[,1]
    uni_x <- unique(clusters)
    nregcl <- sapply(uni_x,function(ex) length(which(clusters==ex)))
    x <- nregcl
    xrange <- c(0, sum(x) + 1)
    yrange <- c(-1, 1)
    
    #A numerical vector of the form c(bottom, left, top, right)
    #which gives the number of lines of margin to be specified on the four sides of the plot. The default is c(5, 4, 4, 2) + 0.1. 
    
    par(mar=c(3,2.5,2.5,2.5))
    plot(xrange, yrange, type="n",
         xlim=xrange, ylim=yrange,
         axes=FALSE,xlab="",ylab="")
    
    #y <- as.vector(table(result.table$chromosome))
    #if(data.file == "Douglas") y <- datacgh[,3] else y <- datacgh[,1]
    y<- datainfo$chromosome
    chromos <- unique(y)
    ch.mid <- sapply(chromos,function(chr) median(which(y==chr)))
    ch.start <- 0.5+c(0,sapply(chromos,function(chr) max(which(y==chr))))
    ## x coordinate for chromosome index
    #ch.mid <- sort(cumsum(y) %% sum(x)) + 1 + (y %/% 2)
    
    ## use odd chromosome indices
    ch.loc <- seq(min(chromos), max(chromos), by=2)
    
    ## make x and y coordinate
    axis(1, at=ch.mid, labels=c(as.character(chromos)))
    axis(2, c(0, 0.5, 1))
    tickright <- c(-0.25,0, 0.25)
    labs<-as.character(abs(tickright))
    axis(4, at=tickright-0.5,labels=labs)
    
    ## identify clusters with white and yellow color
    xcluster <- c(0, cumsum(x))+.5
    ncl <- length(xcluster)
    nreg <- max(xcluster)
    for(i in 1:(ncl - 1))
    {
        if (i %% 2 == 0)
            rect(xcluster[i], yrange[1], xcluster[i+1], yrange[2], border=NA, col="white")
        else
            rect(xcluster[i], yrange[1], xcluster[i+1], yrange[2], border=NA, col="lightgrey")
    }
    
    ## identify significant cluster with dark grey
    sig.cluster <- unlist(lapply(testresults, function(x) x[1, 6])) #sixth column is cluster number
    sig.region <- unlist(lapply(testresults, function(x) x[which(x[,12]<=alpha),1])) #12th column is adjusted pvalue for region
    
    for(j in sig.cluster) rect(xcluster[j], 0.8, xcluster[j+1], yrange[2], border=NA, col=grey(0.3))
    
    
    ticksamp <- sig.region
    axis(3,at=ticksamp, labels=FALSE, col = "black", col.axis="black",srt=270,las=1,cex.axis=1,cex.lab=1)
    
    box()
    ## identify chromosome indices with dashed lines
    xchromosome <- ch.start
    nch <- length(xchromosome)
    for (i in 1:(nch - 1))
        rect(xchromosome[i], yrange[1], xchromosome[i+1], yrange[2], border=TRUE, col=NA,
             lty="solid", lwd=0.7)

    
    if (sepfile=="yes"){
        dataclinvar <- read.delim(clinvarfile,header=TRUE, sep="\t", na.strings = c("NA","#N/A"),comment.char="%")
        clinvarname <- colnames(dataclinvar)[whclinvar]
        dcv <- dataclinvar[,whclinvar]
        sortdcv <- order(dcv)
        dcvsort <- dcv[sortdcv]
        whlev <- levels(dcvsort)
        groupnames <- sapply(whlev,function(x)paste(clinvarname,"_",x,sep=""))
        datacgh <- datacgh[,sortdcv] #columns of data matrix are ordered according to the groups. Columns should be ordered #according to rows in clinical var data set!
        group <- sapply(whlev,function(x)length(dcvsort[dcvsort==x]))
    }
    ngroup <- length(group)
    if(ngroup>2) print("The sub-plot with differential frequencies can only be used in a two-group setting") else {
    
        datreg1 <- datacgh[,1:group[1]]
        datreg2 <- datacgh[,-(1:group[1])]
        ct <- function(vec,x){length(vec[vec==x])}
        count1 <- apply(datreg1,1,ct,x=1)/group[1] - apply(datreg2,1,ct,x=1)/group[2]
        countmin1 <- apply(datreg1,1,ct,x=-1)/group[1]- apply(datreg2,1,ct,x=-1)/group[2]
        sumabs1 <- abs(count1)
        sumabsmin1<-abs(countmin1)     
        con<-1
        #con<-0.5
        lines(c(0.5,nreg),c(-0.5,-0.5))
        for(i in 1:nreg)
        {
                rect(i-1+.5, -0.5, i+.5, -0.5+con*sumabs1[i], border=NA, col="green")  
        }
        for(i in 1:nreg)
        {
                rect(i-1+.5, -0.5, i+.5, -0.5-con*sumabsmin1[i], border=NA, col="red")  
        }
        print(paste("Group 1: ",groupnames[1]," ,Group 2: ",groupnames[2]))
        print("Green: difference between proportion of gains; Red: difference between proportions of losses (group 1 - group 2)")
    }
    
    
    ## gamma-plot
    x.coeff <- 1/2*(xcluster[1:(ncl - 1)] + xcluster[2:ncl])
    whichst <- unique(sapply(clusters,function(x) min(which(clusters==x))))
    y.coeff <- clust[whichst,3]
    
    points(x.coeff, y.coeff,pch=4,cex=0.5)
    print("Chromosomes on the bottom axis, separated by solid lines.")
    print("Alternating light-grey and white bars demarcate clusters.")
    print("Crosses show the association coefficients (scale on left axis).")
    print("Dark-grey bars: significant clusters, tick marks at the top axis: significant regions") 
}
